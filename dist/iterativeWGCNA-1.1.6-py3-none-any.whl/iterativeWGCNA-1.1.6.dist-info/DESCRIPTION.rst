Iterative application of
Weighted Gene Correlation Network Analysis (WGCNA)
to improve whole-transcriptome gene classification

